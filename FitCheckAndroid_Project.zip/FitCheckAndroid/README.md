# FitCheck Android

FitCheck adalah aplikasi Android native sederhana bertema pink-lilac untuk rekomendasi outfit.

## Fitur
- Rekomendasi outfit berdasarkan acara, style, dan cuaca.
- Closet untuk menambah dan menghapus item pakaian.
- Menyimpan dan menghapus outfit favorit.
- Data tersimpan lokal menggunakan Android SharedPreferences, sehingga tetap ada setelah aplikasi ditutup.
- Tidak memerlukan akun atau koneksi internet.

## Build APK dengan Android Studio
1. Instal Android Studio versi stabil terbaru.
2. Pastikan Android SDK Platform 35 dan JDK yang kompatibel dengan Android Gradle Plugin 8.7.3 tersedia.
3. Ekstrak ZIP ini.
4. Android Studio > Open > pilih folder `FitCheckAndroid` (folder yang berisi `settings.gradle`).
5. Tunggu Gradle Sync selesai. Jika diminta, izinkan Android Studio mengunduh Gradle/Android Gradle Plugin dari repositori resmi.
6. Pilih menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Setelah selesai, klik **locate** pada notifikasi build. APK debug biasanya ada di:
   `app/build/outputs/apk/debug/app-debug.apk`
8. Pindahkan APK ke ponsel Android, lalu buka file tersebut. Jika diminta, izinkan instalasi dari sumber itu di pengaturan Android.

## Catatan
- Ini adalah source project Android Studio, bukan APK yang sudah dikompilasi.
- Build membutuhkan koneksi internet saat Gradle mengunduh dependensi pertama kali.
- Untuk rilis publik, buat signing key sendiri melalui Build > Generate Signed Bundle / APK.
