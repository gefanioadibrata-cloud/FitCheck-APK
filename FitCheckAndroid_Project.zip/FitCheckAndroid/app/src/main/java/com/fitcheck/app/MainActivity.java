package com.fitcheck.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(255, 247, 252);
    private final int PINK = Color.rgb(236, 105, 169);
    private final int LILAC = Color.rgb(185, 159, 235);
    private final int DARK = Color.rgb(64, 47, 73);
    private final int MUTED = Color.rgb(125, 105, 130);
    private SharedPreferences prefs;
    private LinearLayout root, content, nav;
    private String currentPage = "outfit";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("fitcheck_data", MODE_PRIVATE);
        seedWardrobe();
        buildShell();
        showPage("outfit");
    }

    private void seedWardrobe() {
        if (prefs.contains("wardrobe")) return;
        JSONArray a = new JSONArray();
        String[][] defaults = {
            {"White oversized shirt","Atasan","Putih"},
            {"Blue jeans","Bawahan","Biru"},
            {"Pink cardigan","Outer","Pink"},
            {"Black sneakers","Sepatu","Hitam"},
            {"Lilac skirt","Bawahan","Lilac"}
        };
        try {
            for (String[] item : defaults) {
                JSONObject o = new JSONObject();
                o.put("name", item[0]); o.put("category", item[1]); o.put("color", item[2]);
                a.put(o);
            }
        } catch (JSONException ignored) {}
        prefs.edit().putString("wardrobe", a.toString()).apply();
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(22), dp(18), dp(22), dp(16));
        header.setBackground(rounded(PINK, 0, 24));
        TextView brand = text("fitcheck ✿", 27, Color.WHITE, true);
        TextView sub = text("your closet, your vibe", 13, Color.WHITE, false);
        header.addView(brand); header.addView(sub);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(dp(14), dp(12), dp(14), dp(8));
        root.addView(header, hp);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(8), dp(18), dp(8));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(8), dp(8), dp(8), dp(12));
        nav.setBackgroundColor(Color.WHITE);
        String[][] items = {{"outfit","✨ Outfit"},{"wardrobe","👚 My Closet"},{"saved","💗 Saved"}};
        for (String[] item : items) {
            Button b = new Button(this);
            b.setText(item[1]); b.setTextSize(11); b.setAllCaps(false);
            b.setTextColor(DARK); b.setBackground(rounded(0xFFFFE6F2, 0, 18));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1);
            p.setMargins(dp(4), 0, dp(4), 0);
            nav.addView(b, p);
            b.setOnClickListener(v -> showPage(item[0]));
        }
        root.addView(nav);
    }

    private void showPage(String page) {
        currentPage = page;
        content.removeAllViews();
        if ("outfit".equals(page)) outfitPage();
        else if ("wardrobe".equals(page)) wardrobePage();
        else savedPage();
    }

    private void outfitPage() {
        addTitle("Outfit of the day", "Pick your plan and let's style it ✨");
        LinearLayout card = card();
        addLabel(card, "Kamu mau ke mana?");
        Spinner event = spinner(new String[]{"Sekolah","Hangout","Acara formal","Olahraga","Di rumah"});
        card.addView(event);
        addLabel(card, "Style yang kamu suka");
        Spinner style = spinner(new String[]{"Casual","Streetwear","Coquette","Minimalist","Sporty"});
        card.addView(style);
        addLabel(card, "Cuaca hari ini");
        Spinner weather = spinner(new String[]{"Cerah","Dingin / hujan","Panas"});
        card.addView(weather);
        Button generate = primaryButton("✨  Generate my fit");
        card.addView(generate, fullTop());
        content.addView(card);

        LinearLayout result = card();
        addTitleTo(result, "Your fit recipe", "Rekomendasi berdasarkan pilihanmu");
        TextView resultText = text("Pilih preferensimu lalu tekan tombol di atas 💗", 14, MUTED, false);
        resultText.setPadding(0, dp(6), 0, dp(8));
        result.addView(resultText);
        Button save = primaryButton("♡  Save this outfit");
        result.addView(save, fullTop());
        content.addView(result);
        final String[] generated = {""};

        generate.setOnClickListener(v -> {
            String e = event.getSelectedItem().toString();
            String s = style.getSelectedItem().toString();
            String w = weather.getSelectedItem().toString();
            String top, bottom, shoes, extra;
            if (s.equals("Coquette")) {
                top = "Pink cardigan atau blouse manis";
                bottom = e.equals("Sekolah") ? "Rok / celana bahan yang sesuai aturan sekolah" : "Rok lilac atau cream";
                shoes = "Mary Janes atau sneakers putih";
                extra = "Pita kecil + tas pastel";
            } else if (s.equals("Streetwear")) {
                top = "Oversized tee";
                bottom = "Loose jeans atau cargo pants";
                shoes = "Chunky sneakers";
                extra = "Cap + sling bag";
            } else if (s.equals("Minimalist")) {
                top = "Kemeja putih atau basic top";
                bottom = "Celana straight-cut warna netral";
                shoes = "Sneakers putih bersih";
                extra = "Tas simpel + aksesori minimal";
            } else if (s.equals("Sporty")) {
                top = "Kaos breathable";
                bottom = "Jogger atau training pants";
                shoes = "Running shoes";
                extra = "Tote bag + botol minum";
            } else {
                top = "Kaos basic atau kemeja putih";
                bottom = "Blue jeans atau celana bahan";
                shoes = "Sneakers favorit";
                extra = "Shoulder bag + aksesori simpel";
            }
            if (w.equals("Dingin / hujan")) extra += "\n🧥 Tambahkan outer dan bawa payung.";
            else if (w.equals("Panas")) extra += "\n☀️ Pilih bahan yang ringan dan nyaman.";
            if (e.equals("Sekolah")) extra += "\n🎒 Pastikan outfit sesuai aturan sekolah.";
            if (e.equals("Acara formal")) { top = "Blouse atau kemeja rapi"; bottom = "Celana bahan atau rok formal"; shoes = "Flat shoes atau sepatu formal"; }
            if (e.equals("Olahraga")) { top = "Kaos olahraga"; bottom = "Celana training"; shoes = "Sepatu olahraga"; }
            generated[0] = "📍 " + e + "  •  " + s + "\n\n👚 ATASAN\n" + top +
                    "\n\n👖 BAWAHAN\n" + bottom + "\n\n👟 SEPATU\n" + shoes + "\n\n💫 FINISHING TOUCH\n" + extra;
            resultText.setText(generated[0]);
        });
        save.setOnClickListener(v -> {
            if (generated[0].isEmpty()) {
                toast("Generate outfit dulu ya ✨");
                return;
            }
            JSONArray arr = readArray("saved");
            arr.put(generated[0]);
            prefs.edit().putString("saved", arr.toString()).apply();
            toast("Outfit tersimpan di Saved 💗");
        });
    }

    private void wardrobePage() {
        addTitle("My closet 👚", "Catat item favoritmu di sini");
        LinearLayout form = card();
        EditText name = edit("Nama item (contoh: cardigan pink)");
        Spinner category = spinner(new String[]{"Atasan","Bawahan","Outer","Sepatu","Aksesori","Tas"});
        EditText color = edit("Warna item");
        form.addView(name); form.addView(category); form.addView(color);
        Button add = primaryButton("+ Tambah ke closet");
        form.addView(add, fullTop());
        content.addView(form);

        add.addOnClickListener(v -> {
            String n = name.getText().toString().trim();
            String c = color.getText().toString().trim();
            if (n.isEmpty() || c.isEmpty()) {
                toast("Isi nama item dan warnanya dulu ya.");
                return;
            }
            JSONArray arr = readArray("wardrobe");
            try {
                JSONObject o = new JSONObject();
                o.put("name", n); o.put("category", category.getSelectedItem().toString()); o.put("color", c);
                arr.put(o);
                prefs.edit().putString("wardrobe", arr.toString()).apply();
                name.setText(""); color.setText("");
                showPage("wardrobe");
                toast("Item berhasil ditambahkan ✨");
            } catch (JSONException ex) { toast("Item gagal disimpan."); }
        });

        addSectionTitle("Isi closet kamu");
        JSONArray arr = readArray("wardrobe");
        if (arr.length() == 0) addText("Belum ada item. Tambahkan item pertamamu!");
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            final int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(10), dp(8), dp(10));
            row.setBackground(rounded(Color.WHITE, 0, 16));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.setMargins(0, dp(4), 0, dp(4));
            TextView info = text("👚 " + o.optString("name") + "\n" + o.optString("category") + " • " + o.optString("color"), 13, DARK, false);
            row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
            Button del = new Button(this); del.setText("Hapus"); del.setTextSize(11); del.setAllCaps(false);
            del.setTextColor(PINK); del.setBackground(rounded(0xFFFFE6F2, 0, 14));
            row.addView(del);
            del.setOnClickListener(v -> {
                JSONArray old = readArray("wardrobe");
                JSONArray fresh = new JSONArray();
                for (int j = 0; j < old.length(); j++) if (j != index) fresh.put(old.opt(j));
                prefs.edit().putString("wardrobe", fresh.toString()).apply();
                showPage("wardrobe");
                toast("Item dihapus.");
            });
            content.addView(row, rp);
        }
    }

    private void savedPage() {
        addTitle("Saved fits 💗", "Outfit yang kamu simpan");
        JSONArray arr = readArray("saved");
        if (arr.length() == 0) {
            LinearLayout empty = card();
            addTextTo(empty, "Belum ada outfit tersimpan.\nBuka tab Outfit, generate look, lalu tekan Save this outfit ✨");
            content.addView(empty);
            return;
        }
        for (int i = arr.length() - 1; i >= 0; i--) {
            final int index = i;
            String fit = arr.optString(i);
            LinearLayout c = card();
            TextView t = text(fit, 14, DARK, false);
            c.addView(t);
            Button delete = primaryButton("Hapus dari Saved");
            c.addView(delete, fullTop());
            delete.setOnClickListener(v -> {
                JSONArray old = readArray("saved");
                JSONArray fresh = new JSONArray();
                for (int j = 0; j < old.length(); j++) if (j != index) fresh.put(old.opt(j));
                prefs.edit().putString("saved", fresh.toString()).apply();
                showPage("saved");
                toast("Outfit dihapus.");
            });
            content.addView(c);
        }
    }

    private JSONArray readArray(String key) {
        try { return new JSONArray(prefs.getString(key, "[]")); }
        catch (JSONException e) { return new JSONArray(); }
    }

    private void addTitle(String title, String subtitle) {
        TextView t = text(title, 22, DARK, true);
        content.addView(t);
        TextView s = text(subtitle, 13, MUTED, false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(3), 0, dp(14));
        content.addView(s, p);
    }

    private void addTitleTo(LinearLayout target, String title, String subtitle) {
        target.addView(text(title, 18, DARK, true));
        target.addView(text(subtitle, 12, MUTED, false));
    }
    private void addLabel(LinearLayout target, String value) {
        TextView t = text(value, 13, DARK, true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(10), 0, dp(4)); target.addView(t, p);
    }
    private void addSectionTitle(String value) {
        TextView t = text(value, 17, DARK, true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(16), 0, dp(8)); content.addView(t, p);
    }
    private void addText(String value) {
        content.addView(text(value, 14, MUTED, false));
    }
    private void addTextTo(LinearLayout target, String value) {
        target.addView(text(value, 14, MUTED, false));
    }
    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(15), dp(16), dp(16));
        c.setBackground(rounded(Color.WHITE, 0, 20));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, dp(14));
        c.setLayoutParams(p);
        c.setElevation(dp(2));
        return c;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Spinner spinner(String[] options) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, options);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        return s;
    }
    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setTextSize(14); e.setHint(hint);
        e.setPadding(dp(12), dp(7), dp(12), dp(7));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(5), 0, dp(5));
        e.setLayoutParams(p);
        e.setBackground(rounded(0xFFFFF5FA, 0xFFF0D5E7, 14));
        return e;
    }
    private Button primaryButton(String label) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false); b.setTextSize(14);
        b.setTextColor(Color.WHITE); b.setBackground(rounded(PINK, 0, 16));
        return b;
    }
    private LinearLayout.LayoutParams fullTop() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(12), 0, 0); return p;
    }
    private GradientDrawable rounded(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
}
